/*
 *
 *
 * ein recursive descent parser fuer eine kleine Grammatik
 * (c) AVH 2008
 *
 *
 */

satz(X) -->
        wsatz(W),
        dsatz(D),
        {X=satz(W,D)}.
satz(X) -->
        nsatz(X).


wsatz(X) -->
        [wenn], pp(PP), sub(Sub), verb(Verb),
        {X=wsatz(wenn,PP,Sub,Verb)}.
wsatz(X) -->
        [wenn], sub(Sub), obj(Obj), verb(Verb),
        {X=wsatz(wenn,Sub,Obj,Verb)}.

dsatz(X) -->
        [dann], verb(Verb), sub(Sub), obj(Obj), vv(VV),
        {X=dsatz(dann,Verb,Sub,Obj,VV)}.
dsatz(X) -->
        verb(Verb), sub(Sub), obj(Obj), vv(VV),
        {X=dsatz(Verb,Sub,Obj,VV)}.

nsatz(X) -->
        sub(Sub), verb(Verb), obj(Obj), vv(VV),
        {X=nsatz(Sub,Verb,Obj,VV)}.
nsatz(X) -->
        sub(Sub), verb(Verb),
        {X=nsatz(Sub,Verb)}.


pp(X) -->
        [hinter],nom(Nom),
        {X=pp(hinter,Nom)}.
pp(X) -->
        [vor],nom(Nom),
        {X=pp(vor,Nom)}.

sub(X) -->
        nom(Nom),
        {X=sub(Nom)}.

obj(X) -->
        nom(Nom),
        {X=obj(Nom)}.

verb(X) -->
        [fliegen],
        {X=verb(fliegen)}.
verb(X) -->
        [fahren],
        {X=verb(fahren)}.
verb(X) -->
        [marschieren],
        {X=verb(marschieren)}.

nom(X) -->
        [fliegen],
        {X=nom(fliegen)}.
nom(X) -->
        [ameisen],
        {X=nom(ameisen)}.
nom(X) -->
        [menschen],
        {X=nom(menschen)}.
nom(X) -->
        [autos],
        {X=nom(autos)}.

vv(X) -->
        [voraus],
        {X=vv(voraus)}.
vv(X) -->
        [hinterher],
        {X=vv(hinterher)}.



parse(Input,Tree) :-
  satz(Tree,Input,[]).



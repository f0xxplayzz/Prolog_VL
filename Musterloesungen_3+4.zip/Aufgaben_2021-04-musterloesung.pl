/*
 * Vorlesung: "Grundlagen der logischen Programmierung"
 * Dozent:    Prof. Dr. Antonius van Hoof
 * DHBW Stuttgart Campus Horb
 *
 * Musterloesungen
 *
 * Bitte, seien Sie fair: Benutzen Sie diese L�sungen nur
 * zu Ihrer pers�nlichen Erbauung!
 * Geben Sie diese L�sungen nicht an Dritten weiter,
 * inbesondere nicht an Kommilitonen in Jahrgaengen nach Ihnen.
 *
 */

 /* Aufgabenblock 3 */

/*********************************************************************
 Aufgabe 1

Auf dem ersten Blick funktioniert das Programm einwandfrei.
Dies ist allerdings nur bei g�ltigen Zielzust�nden der Fall.
Falls man beim urspr�nglichen Programm einen nicht-valide Weltzustand
herstellen will, dann kann das Programm in einer Endlosschleife geraten.
(Als Beispiel diene: do([on(b,table), on(c,b), on(a,b)]).
Dieser Zustand ist ung�ltig, weil nicht zwei Bl�cke (hier: c und a)
direkt auf einem Block (hier: b) stehen k�nnen. Um Endlosschleifen zu
vermeiden ist das Pr�dikat valid/1 vorgesehen. Dies existiert nur als
Platzhalter im Programm. Schreiben Sie den Code f�r valid/1.

**********************************************************************/

:- consult('aufgaben_2021-04-ohne_valid.pl').

%!	valid(ListOfWorldFacts:list) is nondet.
%
%	Das Praedikat, das Aufgabe 1 loest
%
valid([]).
valid(WorldDescription) :-
        \+ ( member(on(Block,table),WorldDescription), dif(Block,table)),
        !,
        writeln('World description is not complete.'),
	writeln('at least one block should rest on the table'),
        abort.
valid([on(table,_)|_]) :-
	!,
	writeln('World description is not valid.'),
	writeln('Cannot put table on top of anything! Aborting'), abort.
valid([on(A,A)|_]) :-
	!,
	writeln('World description is not valid.'),
	write('Cannot put '),write(A),writeln(' on top of itself! Aborting'),
	abort.
valid([on(A,B)|Rest]) :-
        transitive_on(Rest,[A,B],Tower), dif(B,table),
        !,
        writeln('World description is not valid.'),
	writeln('Cannot put blocks mutually on each other: '),
        write('Inconsistent tower: '), writeln(Tower),
        abort.
valid([on(A,B)|Rest]) :-
	member(on(B,A),Rest),
	!,
	writeln('World description is not valid.'),
	write('Cannot put blocks mutually on each other: '),
	write(on(A,B)/on(B,A)),
	writeln('! Aborting'), abort.
valid([on(A,B)|Rest]) :-
	member(on(A,O),Rest), dif(B,O),
	!,
	writeln('World description is not valid.'),
	write('Cannot put '),write(A), write(' both on '),
	write(B), write(' and '), write(O), writeln('! Aborting'),
	abort.
valid([on(A,B)|Rest]) :-
	member(on(O,B),Rest), dif(A,O), dif(B,table),
	!,
	writeln('World description is not valid.'),
	write('Cannot put both '),write(A), write(' and '), write(O),
	write(' on top of '), write(B), writeln('! Aborting'), abort.
valid([_|Rest]) :-
	valid(Rest).



transitive_on([on(A,B)|_],[B|Tower],[A,B|Tower]) :-
        member(A,Tower),
        !.
transitive_on([on(A,B)|Rest],[B|Tower],NewTower) :-
        !,
        transitive_on(Rest,[A,B|Tower],NewTower).
transitive_on([on(A,B)|_],Tower,[A,B|Tower]) :-
        member(B,Tower),
        !.
transitive_on([on(A,B)|Rest],Tower,NewTower) :-
        last(Tower,A),
        !,
        append(Tower,[B],TmpTower),
        transitive_on(Rest,TmpTower,NewTower).
transitive_on([_|Rest],Tower,NewTower) :-
        transitive_on(Rest,Tower,NewTower).
%
% NB: this does not yet deal with all transitive situations
%     when the on() descriptions are not ordered


/*********************************************************************
 Aufgabe 2

�ndern Sie das Blocksworld Programm so ab, dass es ohne assert und
retract auskommt. Dies erreichen Sie wenn Sie zus�tzliche Argumente in
den Prozederen f�r Weltzustand und Aktionsplan mitf�hren.

**********************************************************************/

%	NB: diese Programm braucht die Pr�dikate, definiert in
%	'aufgaben_2016-03-ohne_valid.pl' nicht mehr.
%	(Sie schaden allerdings auch nicht, weil die neue Pr�dikate zwar
%	teils gleiche Namen aber andere Arity haben)


%!	move(+StartState:list,+GoalState:list,-Moves:list) is nondet.
%
%	Das Toplevelpr�dikat f�r Aufgabe 2. StartState ist eine Liste, die
%	den Anfangszustand beschreibt (z.B.: [on(a,b),on(b,c),on(c,table)])
%	GoalState ist eine �hnliche Liste, die den Zielzustand der Welt
%	beschreibt. Moves enth�lt bei Erfolg die Liste der Aktionen, die
%	auzszuf�hren sind um den StartState in den GoalState zu �berf�hren.
%
move(StartState, GoalState, Moves) :-
	valid(StartState), valid(GoalState),
	do(GoalState,StartState,_,[],RevMoves, GoalState),
	reverse(RevMoves,Moves).

do([Goal|RestGoals],StartState,ResultState,OldMoves,Moves,GoalState) :-
	member(Goal,StartState),     /* already achieved            */
	!,                           /* continue with rest of goals */
	do(RestGoals,StartState,ResultState,OldMoves,Moves,GoalState).
do([Goal|_],StartState,ResultState,OldMoves,Moves,GoalState) :-
	/* must do work to achieve */
	achieve(Goal,StartState,TmpState,OldMoves,TmpMoves),
	/* go back and check previous goals */
	do(GoalState,TmpState,ResultState,TmpMoves,Moves,GoalState).
do([],State,State,Moves,Moves,_).    /* finished */


achieve(on(A,B),StartState,ResultState,OldMoves,Moves) :-
	r_put_on(A,B,StartState,ResultState,OldMoves,Moves).


r_put_on(A,B,State,State,Moves,Moves) :-
	member(on(A,B),State), !.
r_put_on(A,B,State,[on(A,B)|RState],Moves,[move(A,X,B)|NewMoves]) :-
	dif(A,table),
	dif(A,B),
	clear_off(A,State,TmpState,Moves,TmpMoves),
	clear_off(B,TmpState,NewState,TmpMoves,NewMoves),
	member(on(A,X),NewState),
	!,
	delete(NewState,on(A,X),RState).


clear_off(table,State,State,Moves,Moves) :- !.    /* There is room on table */
clear_off(A,State,State,Moves,Moves) :-           /* Means already clear */
     \+ member(on(_X,A),State),
	 !.
clear_off(A,State,[on(X,table)|RState],Moves,[move(X,A,table)|NewMoves]) :-
     member(on(X,A),State),
     clear_off(X,State,NewState,Moves,NewMoves),
     delete(NewState,on(X,A),RState).


clear(table,_) :- !.
clear(B, IState) :-
     % B \== table,
     \+ member(on(_X,B),IState).


put_on(A,B,IState,[on(A,B)|RState],Moves,[move(A,X,B)|Moves]) :-
     dif(A,table),
     dif(A,B),
     member(on(A,X),IState),
     clear(A,IState),
     clear(B,IState),
     delete(IState,on(A,X),RState).




/*********************************************************************
 Aufgabe 3

Wenn Sie ein wenig mit dem Programm herumspielen, werden Sie schnell
merken, dass es keine sonderlich intelligenten Pl�ne erstellt.
Versuchen Sie das Programm dahingehend zu optimieren, dass es keine
�berfl�ssigen Aktionen plant. (Hint: untersuchen sie die Reihenfolge
der Fakten in der Zielzustandsbeschreibung).

**********************************************************************/



%!	move_opt(+StartState:list,+GoalState:list,-Moves:list) is nondet.
%
%	Das Toplevelpr�dikat der Aufgabe 3. StartState ist eine Liste, die
%	den Anfangszustand beschreibt (z.B.: [on(a,b),on(b,c),on(c,table)])
%	GoalState ist eine �hnliche Liste, die den Zielzustand der Welt
%	beschreibt. Moves enth�lt bei Erfolg die Liste der Aktionen, die
%	auzszuf�hren sind um den StartState in den GoalState zu �berf�hren.
%	In Vergleich zu move/3 wird hier die GoalState in eine optimale
%	Reihenfolge gebracht f�r die k�rzeste L�sung.
%	Zust�ndig daf�r ist order_goalstate/2.
%
%	Zus�tzlicher Optimierung zur Vermeidung von reverse/2:
%	die Benutzung von Differenzlisten in do/5 und alle davon
%	aufgerufenen Pr�dikaten.
%
move_opt(StartState, GoalState, Moves) :-
	valid(StartState), valid(GoalState),
	order_goalstate(GoalState,OrderedGoalState),
	do(OrderedGoalState,StartState,_,Moves/[], OrderedGoalState).


do([Goal|RestGoals],StartState,ResultState,Move/Moves,GoalState) :-
	member(Goal,StartState),     /* already achieved            */
	!,                           /* continue with rest of goals */
	do(RestGoals,StartState,ResultState,Move/Moves,GoalState).
do([Goal|_],StartState,ResultState,Move/Moves,GoalState) :-
	/* must do work to achieve */
	achieve(Goal,StartState,TmpState,Move/TmpMoves),
	/* go back and check previous goals */
	do(GoalState,TmpState,ResultState,TmpMoves/Moves,GoalState).
do([],State,State,Moves/Moves,_).    /* finished */


achieve(on(A,B),StartState,ResultState,Move/Moves) :-
	r_put_on(A,B,StartState,ResultState,Move/Moves).


r_put_on(A,B,State,State,Moves/Moves) :-
	member(on(A,B),State), !.
r_put_on(A,B,State,[on(A,B)|RState],Moves/NewMoves) :-
	dif(A,table),
	dif(A,B),
	clear_off(A,State,TmpState,Moves/TmpMoves),
	clear_off(B,TmpState,NewState,TmpMoves/[move(A,X,B)|NewMoves]),
	member(on(A,X),NewState),
	!,
	delete(NewState,on(A,X),RState).


clear_off(table,State,State,Moves/Moves) :- !.    /* There is room on table */
clear_off(A,State,State,Moves/Moves) :-           /* Means already clear */
     \+ member(on(_X,A),State).
clear_off(A,State,[on(X,table)|RState],Moves/NewMoves) :-
     member(on(X,A),State),
     clear_off(X,State,NewState,Moves/[move(X,A,table)|NewMoves]),
     delete(NewState,on(X,A),RState).


order_goalstate([],[]) :- !.
order_goalstate(Goals,[on(OneUp,table)|OrderedGoals]) :-
	select(on(OneUp,table),Goals,RestGoals),
	order_goals(OneUp,RestGoals,OrderedGoals).

order_goals(_Block,[],[]) :- !.
order_goals(Block,Goals,[on(OneUp,Block)|Order]) :-
	select(on(OneUp,Block),Goals,RestGoals),
	!,
	order_goals(OneUp,RestGoals,Order).
order_goals(_,Goals,Ordered) :-
	order_goalstate(Goals,Ordered).





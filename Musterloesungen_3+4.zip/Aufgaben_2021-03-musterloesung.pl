/*
 * Vorlesung: "Grundlagen der logischen Programmierung"
 * Dozent:    Prof. Dr. Antonius van Hoof
 * DHBW Stuttgart Campus Horb
 *
 * Musterloesungen
 *
 * Bitte, seien Sie fair: Benutzen Sie diese L�sungen nur
 * zu Ihrer pers�nlichen Erbauung!
 * Geben Sie diese L�sungen nicht an Dritten weiter,
 * inbesondere nicht an Kommilitonen in Jahrgaengen nach Ihnen.
 *
 */

 /* Aufgabenblock 4 */


/************************************************************************
 Aufgabe 1

In der Vorlesung wurde Ihnen u.a. das Problem des 8-ter Puzzles
vermittelt. Schreiben Sie ein Programm, das f�r eine gegebene
verschobene Konstellation eine L�sung angibt, d.h. aufzeigt, welche
Schiebeaktionen vorzunehmen sind. Falls es keine L�sung gibt (Falsche
8-ter Puzzle) soll es dies nat�rlich auch ausgeben.

*************************************************************************/

% we go for the A* solutions, both breadth-first
% and with iterative deepening.
% simply use the implementations already given
% (with the example problem removed!)
%
% Please note their differences in performance!

:- consult('aufgaben_2016-04-a-star.pl').
:- consult('aufgaben_2016-04-ida-star.pl').


%	We allow for different Goal states
%   The obvious one is already entered as default
:- dynamic goal/1.

goal(pz(0,1,2,
	    3,4,5,
	    6,7,8)).

%%	There are not so many generic 3x3 postions
%%  (only considering the empty tile, encoded as 0
%%	We can simply list them all with all allowed transitions
%%	With bigger NxN Problems we would probably have to generate them
%%	(Left as an excercise to you)

%% move 0 left in the top row
move(pz(X1,0,X3, X4,X5,X6, X7,X8,X9),
     pz(0,X1,X3, X4,X5,X6, X7,X8,X9), 1).
move(pz(X1,X2,0, X4,X5,X6, X7,X8,X9),
     pz(X1,0,X2, X4,X5,X6, X7,X8,X9), 1).

%% move 0 left in the middle row
move(pz(X1,X2,X3, X4,0,X6,X7,X8,X9),
     pz(X1,X2,X3, 0,X4,X6,X7,X8,X9), 1).
move(pz(X1,X2,X3, X4,X5,0,X7,X8,X9),
     pz(X1,X2,X3, X4,0,X5,X7,X8,X9), 1).

%% move left in the bottom row
move(pz(X1,X2,X3, X4,X5,X6, X7,0,X9),
     pz(X1,X2,X3, X4,X5,X6, 0,X7,X9), 1).
move(pz(X1,X2,X3, X4,X5,X6, X7,X8,0),
     pz(X1,X2,X3, X4,X5,X6, X7,0,X8), 1).

%% move 0 right in the top row
move(pz(0,X2,X3, X4,X5,X6, X7,X8,X9),
     pz(X2,0,X3, X4,X5,X6, X7,X8,X9), 1).
move(pz(X1,0,X3, X4,X5,X6, X7,X8,X9),
     pz(X1,X3,0, X4,X5,X6, X7,X8,X9), 1).

%% move 0 right in the middle row
move(pz(X1,X2,X3, 0,X5,X6, X7,X8,X9),
     pz(X1,X2,X3, X5,0,X6, X7,X8,X9), 1).
move(pz(X1,X2,X3, X4,0,X6, X7,X8,X9),
     pz(X1,X2,X3, X4,X6,0, X7,X8,X9), 1).

%% move 0 right in the bottom row
move(pz(X1,X2,X3, X4,X5,X6,0,X8,X9),
     pz(X1,X2,X3, X4,X5,X6,X8,0,X9), 1).
move(pz(X1,X2,X3, X4,X5,X6,X7,0,X9),
     pz(X1,X2,X3, X4,X5,X6,X7,X9,0), 1).

%% move 0 up from the middle row
move(pz(X1,X2,X3, 0,X5,X6, X7,X8,X9),
     pz(0,X2,X3, X1,X5,X6, X7,X8,X9), 1).
move(pz(X1,X2,X3, X4,0,X6, X7,X8,X9),
     pz(X1,0,X3, X4,X2,X6, X7,X8,X9), 1).
move(pz(X1,X2,X3, X4,X5,0, X7,X8,X9),
     pz(X1,X2,0, X4,X5,X3, X7,X8,X9), 1).

%% move 0 up from the bottom row
move(pz(X1,X2,X3, X4,X5,X6, X7,0,X9),
     pz(X1,X2,X3, X4,0,X6, X7,X5,X9), 1).
move(pz(X1,X2,X3, X4,X5,X6, X7,X8,0),
     pz(X1,X2,X3, X4,X5,0, X7,X8,X6), 1).
move(pz(X1,X2,X3, X4,X5,X6, 0,X8,X9),
     pz(X1,X2,X3, 0,X5,X6, X4,X8,X9), 1).

%% move 0 down from the top row
move(pz(0,X2,X3, X4,X5,X6, X7,X8,X9),
     pz(X4,X2,X3, 0,X5,X6, X7,X8,X9), 1).
move(pz(X1,0,X3, X4,X5,X6, X7,X8,X9),
     pz(X1,X5,X3, X4,0,X6, X7,X8,X9), 1).
move(pz(X1,X2,0, X4,X5,X6, X7,X8,X9),
     pz(X1,X2,X6, X4,X5,0, X7,X8,X9), 1).

%% move 0 down from the middle row
move(pz(X1,X2,X3, 0,X5,X6, X7,X8,X9),
     pz(X1,X2,X3, X7,X5,X6, 0,X8,X9), 1).
move(pz(X1,X2,X3, X4,0,X6, X7,X8,X9),
     pz(X1,X2,X3, X4,X8,X6, X7,0,X9), 1).
move(pz(X1,X2,X3, X4,X5,0, X7,X8,X9),
     pz(X1,X2,X3, X4,X5,X9, X7,X8,0), 1).


%%	As estimate function we will use the manhatten function (see below)
estimate(State,Distance) :-
	goal(GoalState),
	manhatten(8,State,GoalState,0,Distance).



%%	calculate the number of tile inversions
%%	only if StartState and GoalState are both
%%	odd or both even, then a solution is possible
%%	(see e.g.: http://www.cs.princeton.edu/
%%   courses/archive/fall12/cos226/assignments/8puzzle.html)

inversions(pz(A,B,C,D,E,F,G,H,I),NumberInversions) :-
	select(0,[A,B,C,D,E,F,G,H,I],Tiles),
	% We know there is only one 0 that can be selected
	% but Prolog doesn't. We optimize by putting cut.
	!,
	inv(Tiles,0,NumberInversions).

inv([],N,N).
inv([X|Rest],Acc,N) :-
	xinv(Rest,X,0,NN),
	NewAcc is Acc+NN,
	inv(Rest,NewAcc,N).


xinv([],_,N,N).
xinv([X|Xs],Nr,Acc,N) :-
	(	X<Nr -> NewAcc is Acc+1 ; NewAcc is Acc),
	xinv(Xs,Nr,NewAcc,N).


%%	Calculate the Manhattan distance of the PresentState
%%	to the GoalState. This is an admissable function for A*.
%%	(see e.g.: http://www.cs.princeton.edu/
%%   courses/archive/fall12/cos226/assignments/8puzzle.html)
%%	We consider all tile numbers from 8 downward
manhatten(0,_,_,ManhattenDist,ManhattenDist) :-
	% 0 is not a tile, but the remaining empty space
	!.
manhatten(N,PresentState,GoalState,Accu,ManhattenDist) :-
	N > 0,
	mhdist(N,PresentState,GoalState,TmpDist),
	NewAccu is Accu+TmpDist,
	NN is N-1,
	manhatten(NN,PresentState,GoalState,NewAccu,ManhattenDist).

mhdist(TileNumber,PresentState,GoalState,Dist) :-
	xy_position(TileNumber,PresentState,PresentX,PresentY),
	xy_position(TileNumber,GoalState,GoalX,GoalY),
	Dist is abs(PresentX-GoalX)+abs(PresentY-GoalY).


xy_position(N,pz(N,_,_, _,_,_, _,_,_),1,1).
xy_position(N,pz(_,N,_, _,_,_, _,_,_),2,1).
xy_position(N,pz(_,_,N, _,_,_, _,_,_),3,1).
xy_position(N,pz(_,_,_, N,_,_, _,_,_),1,2).
xy_position(N,pz(_,_,_, _,N,_, _,_,_),2,2).
xy_position(N,pz(_,_,_, _,_,N, _,_,_),3,2).
xy_position(N,pz(_,_,_, _,_,_, N,_,_),1,3).
xy_position(N,pz(_,_,_, _,_,_, _,N,_),2,3).
xy_position(N,pz(_,_,_, _,_,_, _,_,N),1,3).



%!	solve8_astar(+StartState,-Solution,-NrOfMoves) is nondet.
%
%	The User Interface Function to the "normal" A* solver
%	StartState should be of the form pz(_,_,_,_,_,_,_,_,_)
%	with tile numbers in the appropriate positions
%	(left to right, top to bottom listing), using 0 for the
%	empty space. The predicate checks first whether a solution
%	can exist at all, using inversions/2
%
solve8_astar(StartState,Solution,NrOfMoves) :-
	inversions(StartState,InvSS),
	goal(GoalState),
	inversions(GoalState,InvGS),
	ParityStart is mod(InvSS,2),
	ParityGoal is mod(InvGS,2),
	(	ParityStart is ParityGoal -> solve_astar(StartState,Solution/NrOfMoves)
	    ;
	    writeln('Parity of InputState and GoalState are not equal'),
		writeln('Therefore, there is no solution'),
		!, fail
	).



%!	solve8_idastar(+StartState,-Solution,-NrOfMoves) is nondet.
%
%	The User Interface Function to the iterative deepening A* solver
%	StartState should be of the form pz(_,_,_,_,_,_,_,_,_)
%	with tile numbers in the appropriate positions
%	(left to right, top to bottom listing), using 0 for the
%	empty space. The predicate checks first whether a solution
%	can exist at all, using inversions/2
%
solve8_idastar(StartState,Solution,NrOfMoves) :-
	inversions(StartState,InvSS),
	goal(GoalState),
	inversions(GoalState,InvGS),
	ParityStart is mod(InvSS,2),
	ParityGoal is mod(InvGS,2),
	(	ParityStart is ParityGoal ->
	    (	solve_idastar(StartState,Solution),
			length(Solution,N),
			NrOfMoves is N-1
		)
	    ;
	    writeln('Parity of InputState and GoalState are not equal'),
		writeln('Therefore, there is no solution'),
		!, fail
	).




# Sample Websocket Client

SWI-Prolog should be [installed](http://www.swi-prolog.org/download/stable).

To start, go to the project's directory and run
```sh
swipl -s ws-server
```

Then open the index.html file.